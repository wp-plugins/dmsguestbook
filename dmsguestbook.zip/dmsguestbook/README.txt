 + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
 -----------------------------------------------------------------
 DMSGuestbook is released under the GNU General Public License
 http://www.gnu.org/licenses/gpl.html

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 See the GNU General Public License for more details.
 -----------------------------------------------------------------
 This plugin is run and tested under Wordpress 2.2.1

 Plugin name: DMSGuestbook
 Version: 1.0
 Author: Daniel Schurter
 Email: DMSGuestbook@danielschurter.net
 Url: http://DanielSchurter.net

 Thanks to NoGray for the fine color picker, i like it!
 URL: http://www.nogray.com
 -----------------------------------------------------------------
 + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +

 Features:
 You can customize the whole DMSGuestbook to your desire.
 - DMSGuestbook and separator width
 - Position on the page
 - Post per page
 - Text and border color
 - Text color of antispam (anti robot, captcha) text
 - Navigation style and size
 - Date and time format
 - Choose your own DMSGuestbook caption text
 - Preset DMSGuestbook caption text in german, english and swissgerman :-)
 - Set mandatory fields where must be filled out
 - Let's hidden some text in the DMSGuestbook (e.g. IP adress)
 - Manage the DMSGuestbook user entries. (e.g. Name, Message, Url, IP adress)

 Requirement:
 - Wordpress 2.x
 - Exec-PHP (http://bluesome.net/post/2005/08/18/50/)

 Installation:
 1.) Download the dmsguestbook.zip
 2.) Unpack the file and copy the whole dmsguestbook folder to the wordpress plugin folder.
 3.) Activate the DMSGuestbook entry in the plugins section of wordpress.
 4.) You will see in the top of navigation the DMSGuestbook admin link.

 Enjoy it :-)